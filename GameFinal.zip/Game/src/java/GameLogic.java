import java.util.ArrayList;
import java.util.Random;


public class GameLogic {

    public int SIZE;
    public int[][] grid;
    public int DOT_COUNT = 20;  //Random generated dot count
    private Random random = new Random();
    private char colors[] = {'R', 'G', 'B'};  //Coors of dots

    private ArrayList<Player> players_temp =new ArrayList<>();
    private ArrayList<Player> players =new ArrayList<>(); //Players array


    public synchronized int addPlayer(){ //Add a person to the grid object
        players.add(players_temp.get(players.size()));
        return players.size()-1; //return the players ID
    }

    public int playersCount(){
        return players.size();
    }

    public GameLogic(int SIZE) {

        //SIZExSIZE grid
        this.SIZE=SIZE;
        grid = new int[SIZE][SIZE];

        //Temp players
        players_temp.add(new Player("P1", 0, 0, 0));
        players_temp.add(new Player("P2", 0, 0, grid.length - 1));
        players_temp.add(new Player("P3", 0, grid.length - 1, 0));
        players_temp.add(new Player("P4", 0, grid.length - 1, grid.length - 1));

        getRandomGrid(); //Randomly generate points

        //Put the players in to the grid.
        grid[0][0]=97;
        grid[0][grid.length-1]=98;
        grid[grid.length-1][0]=99;
        grid[grid.length-1][grid.length-1]=100;

    }


    private void getRandomGrid(){
        for (int i = 0; i < DOT_COUNT; i++) {
            int x = random.nextInt(SIZE-1), y = random.nextInt(SIZE-1);
            if (x == 0 && y == 0 || x == 0 && y == grid.length - 1 || x == grid.length - 1 && y == grid.length - 1 || y == 0 && x == grid.length - 1) {
                i--; //corner cases are ignored players are at corners
            } else {
                if(grid[x][y] == 0) { //chack the grid point does not contain any pre random generated values
                    grid[x][y] = random.nextInt(1000) % 3 + 1;
                }else {
                    i--;
                }
                }
        }
    }


    public void printGrid() {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }

    public synchronized ArrayList<Coordinates> gridtoCoordinates() {
        //JSON string for current grid.
        ArrayList<Coordinates> coordinates = new ArrayList<>();
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                int c;
                if ((c = grid[i][j]) != 0 && (c < 4)) {
                    coordinates.add(new Coordinates(String.valueOf(colors[c - 1]), i, j));
                }
            }
        }
        return coordinates;
    }

    public synchronized ArrayList<Player> getPlayers(){
        return players;
    } //Return players in the grid

    public synchronized boolean moveonGrid(int person,int diraction){
        if(person > 3) return false; //ID check
        if(this.playersCount() != 4) return false; //Number of players connected
        Player player= players.get(person); //Get the respective player
        int x=player.x; //Get initial position
        int y=player.y;
        int x_n=0,y_n=0;

        if(diraction == 38){  //up
            x_n=x-1;y_n=y;
            if(x_n < 0) x_n=grid.length-1; //Go around the grid
        }else if(diraction == 40) { //down
            x_n = x+1;y_n = y;
            if (x_n > grid.length - 1) x_n = 0; //Go around the grid
        }else if(diraction == 37) {  //left
            x_n =x;y_n = y-1;
            if (y_n < 0) y_n = grid.length-1; //Go around the grid
        }else if(diraction == 39) { //right
            x_n = x;y_n = y+1;
            if (y_n > grid.length -1) y_n = 0; //Go around the grid
        }
        return updateGrid(x, y, x_n, y_n, player);
    }

    public boolean gameOver(){
        return DOT_COUNT==0;
    }

    private boolean updateGrid(int x,int y,int x_n,int y_n,Player player){
        if(grid[x_n][y_n] <= 4){  //Score
            grid[x][y]=0; //Update the grid
            player.x=x_n; //Update x,y coordinates
            player.y=y_n;
            player.updateScore(grid[x_n][y_n]);
            if(grid[x_n][y_n]> 0) {
                DOT_COUNT--; //decrement the dot count 
            }
            grid[x_n][y_n]=97+players.indexOf(player); //Put the person on the grid
            return true;
        }else {//Collide
        int points[]=randomPoints();

            //Edit the player 1
            Player player1=players.get(grid[x_n][y_n]-97);
            grid[player1.x][player1.y]=0;
            player1.x=points[0];
            player1.y=points[1];
            player1.updateScore(-3);
            grid[player1.x][player1.y]=97+players.indexOf(player1);

            //Edit the player
            points=randomPoints();
            player.updateScore(-3);
            grid[player.x][player.y]=0;
            player.x=points[0];
            player.y=points[1];
            grid[player.x][player.y]=97+players.indexOf(player);
        }
        return false;
    }

    private int[] randomPoints(){
        int x = random.nextInt(SIZE-1), y = random.nextInt(SIZE-1);
        while(grid[x][y] != 0){
            x = random.nextInt(SIZE-1);
            y = random.nextInt(SIZE-1);
        }
        int data[]={x,y};
        return data;
    }




}

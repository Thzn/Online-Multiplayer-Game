import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.BeforeClass;

public class GameLogicTest {
    
    static GameLogic logic;
    
    public GameLogicTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
       logic=new GameLogic(10);
       int grid[][]={ //Create a known grid for testing
           {97,3,0,0,0,0,0,0,0,98},
           {0,0,0,0,1,0,2,0,0,0},
           {2,0,0,0,0,0,0,0,0,0},
           {0,0,0,0,0,0,0,0,0,0},
           {1,0,0,0,0,0,0,0,2,0},
           {0,0,0,0,0,0,0,0,0,0},
           {3,0,0,0,0,0,0,3,0,0},
           {2,0,3,0,0,0,0,0,0,0},
           {0,0,0,0,0,0,0,2,0,0},
           {99,3,0,0,0,0,0,0,0,100}
       };      
        logic.grid=grid; //Add players in to the grid for testing grid logic
        logic.addPlayer();
        logic.addPlayer();
        logic.addPlayer();
        logic.addPlayer();
        //***All players are put in to the grid and {94,98,99,100} used to represent them nad players ID{0,1,2,3}
    }
    
    @Test
    public void addPlayerTest(){ //add a one player
      GameLogic temp=new GameLogic(10);
      assertEquals(0,temp.addPlayer());    
    }
    
    @Test
    public void testmoveonGrid() { //Try to move on the grid with less number of players
        GameLogic temp=new GameLogic(10); 
        boolean expResult = false;
        boolean result = temp.moveonGrid(0,38);
        assertEquals(expResult, result);
    }
    
    
    @Test
    public void testmoveonGrid2() { //move to up when 4 players are connected
        System.out.println(logic.playersCount());       
        boolean expResult = true;
        boolean result = logic.moveonGrid(1,40); 
        assertEquals(expResult, result);
        displayResult();
    }
    
    
    @Test
    public void testmoveonGrid3() { //Move the player 2 on grid and check the destination column 
        int expResult = 99;
        logic.moveonGrid(2,38);
        int result =logic.grid[8][0]; 
        assertEquals(expResult, result);
        displayResult();
    }
    
    @Test
    public void testmoveonGrid4() { //Move the player 3 on around the grid go down Check the destination column
        int expResult = 100;
        logic.moveonGrid(3,40);
        int result=logic.grid[0][9];                
        assertEquals(expResult, result); 
        displayResult();
    }
    
    @Test
    public void testmoveonGrid5() { //Move the player 3 down to collide with player 1
        boolean expResult = false;
        boolean result=logic.moveonGrid(3,40);              
        
        int marksexp=-3;
        int marksres=logic.getPlayers().get(3).score; //marks reduction of the player
        
        assertEquals(marksexp, marksres);
        assertEquals(-3,logic.getPlayers().get(1).score);
        assertEquals(expResult, result);
        System.out.print("nnn\n");
        displayResult();        
    }
    
    @Test
    public void testmoeonGrid6() { //Move the player 2 on grid and chack the food count
        int expResult = 99;
        int dotsexp=logic.DOT_COUNT;
        logic.moveonGrid(2,38);        
        int result =logic.grid[7][0]; //Check the destination column        
        int marksexp=2;
        int marksres=logic.getPlayers().get(2).score;
            
        assertEquals(dotsexp-1,logic.DOT_COUNT);//Chec the dot(food count)
        assertEquals(marksexp, marksres);
        assertEquals(expResult, result);
        displayResult();
    }       

    @Test
    public void testmoeonGrid7() { //Move the player 2 on grid and chack the marks update
        int marksexp=logic.getPlayers().get(2).score+3;
        logic.moveonGrid(2,38);
        int marksres=logic.getPlayers().get(2).score;           
        assertEquals(marksexp, marksres);
        displayResult();
    }
    
    private void displayResult(){
      logic.printGrid();
      System.out.println("------------------------");
    }
}

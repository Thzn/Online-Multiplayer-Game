
public class Player {

    String personid;
    int score;
    int x;
    int y;

    public Player(String personid, int score, int x, int y) {
        this.personid = personid;
        this.score = score;
        this.x = x;
        this.y = y;
    }

    public int getScore() {
        return score;
    }

    public void updateScore(int v) {
        this.score =this.score+v;
    }


    @Override
    public String toString() {
        return "[\"" + personid + "\"" + ", "+ score +", "+ x + ", "+ y + "]";
    }
}

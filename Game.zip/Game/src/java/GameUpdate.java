
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/gameUpdate"})
public class GameUpdate extends HttpServlet {

     private GameLogic grid;
    
    @Override
    public void init(final ServletConfig config) {
        grid = new GameLogic(45); //Get a game grid with size of 45*45       
    }

    @Override
    protected void doGet(final HttpServletRequest request, final HttpServletResponse response)
            throws ServletException, IOException{
        
        
        response.setContentType("text/event-stream;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession session=request.getSession();
        
        if(session.isNew() && grid.playersCount() < 4){ //only four players are allowed
           session.setAttribute("number",new Integer(grid.addPlayer()));
           sendData(out);   //Send connection data 
        }
        
        while(grid.playersCount() != 4){ //The loop that sends SSE to indicate number of players
          try{
            Thread.sleep(100); //SSE sends every 100 ms
            }   catch (InterruptedException ex) {
                Logger.getLogger(GameUpdate.class.getName()).log(Level.SEVERE, null, ex);
            }finally{
              sendData(out);
          }}
        try{ //Loop in game play State
        while(!Thread.interrupted()){
            synchronized (this) {
                    wait(); 
                    sendData(out);                   
                    if(grid.gameOver()){
                      grid=new GameLogic(45);
                      grid.addPlayer();
                      grid.addPlayer();
                      grid.addPlayer();
                      grid.addPlayer();
                    }
            }
            }
        }catch(InterruptedException e){
          Logger.getGlobal().log(Level.INFO, "Exiting");
        }

    }

    private void sendData(PrintWriter out){ //SSE response
        out.print("data: ");
        out.println("{" + "\"PLAYERS\" : "+ grid.getPlayers() + ",\"DOTS\": "+ grid.gridtoCoordinates() + "}" );
        out.println();
        out.flush();
    }
    
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {        
        
        HttpSession session=req.getSession();
        
        synchronized (this) { //Game play state keystroke values
            if(grid.playersCount() == 4 && !grid.gameOver()){
            grid.moveonGrid((Integer)session.getAttribute("number"),Integer.parseInt(req.getParameter("keypress")));
            notifyAll();
            } 
        }
    }
   

    
    
    
}
